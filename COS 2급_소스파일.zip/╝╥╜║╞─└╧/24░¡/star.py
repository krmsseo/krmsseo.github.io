import turtle as t
t.shape("turtle")
for x in range(8):
    t.forward(80)
    t.left(135)
    
