
import turtle as t
t.shape("turtle")

t.color(0,0,1)
t.begin_fill()


for x in range(2):
    t.forward(100)
    t.left(90)
    t.forward(30)
    t.left(90)


t.up()
t.backward(50)
t.down()

for x in range(2):
    t.forward(200)
    t.right(90)
    t.forward(50)
    t.right(90)

t.end_fill()

t.color(0,0,0)


t.setheading(270)
t.up()
t.forward(60)
t.setheading(0)
t.forward(60)
t.down()
t.begin_fill()
t.circle(15)
t.end_fill()

t.setheading(0)
t.up()
t.forward(80)
t.down()
t.begin_fill()
t.circle(15)
t.end_fill()



