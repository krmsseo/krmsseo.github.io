import turtle as t

t.shape("turtle")
t.color("yellow")

t.penup()
t.forward(20)
t.pendown()
t.forward(80)

t.penup()
t.forward(20)
t.right(90)
t.forward(20)
t.pendown()
t.forward(80)

t.penup()
t.forward(20)
t.right(90)
t.forward(20)
t.pendown()
t.forward(80)

t.penup()
t.forward(20)
t.right(90)
t.forward(20)
t.pendown()
t.forward(80)
