a=23
b=32
c=(a+b)/2

print(c)
print("%d"%c)
print("%4d"%c)
print("%f"%c)
print("%3.1f"%c)
print("%6.1f"%c)


