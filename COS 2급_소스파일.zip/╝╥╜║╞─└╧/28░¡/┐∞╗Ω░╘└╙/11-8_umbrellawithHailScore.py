#(쉽게 배우는) 파이썬 with 컴퓨팅 사고력 / 황혜정,유현수,박진영,최리사 / 글로벌 출판사 / 11chapter 

import pygame
import random
import time

WHITE = (255, 255, 255)
BLACK = (0,0,0)
LIGHTBLUE = (150, 230, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)

size = [800, 600]
#파이게임 초기화
pygame.init()
running = True
fps = 4

#우박 좌표
stone = []
for i in range(15):
    x = random.randint(1,750)
    y = random.randint(-50, 100)
    stone.append([x,y])
    
#우산 좌표
um_x = 400
um_y = 500

#윈도우 생성
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Avoid Hailstone Game")

font = pygame.font.Font(None,30)   #폰트 생성
score =  0                         #점수 저장할 변수

umbrella = pygame.image.load("umbrella.png").convert_alpha()

control_num = 13
#기준시각으로 현재 시간 저장
st_time = time.time()

pygame.key.set_repeat(100, 50)
clock = pygame.time.Clock()
#우박 좌표 y 변화값
stone_y_change = 10
while running:
    #우산 좌표 변화값 초기화
    um_x_change = 0
    um_y_change = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                um_x_change = -10
            elif event.key == pygame.K_RIGHT:
                um_x_change = 10
            elif event.key == pygame.K_DOWN:
                um_y_change = 10
            elif event.key == pygame.K_UP:
                um_y_change = -10
            elif event.key == pygame.K_ESCAPE:
                running = False
    #우산 좌표 설정
    um_x = um_x + um_x_change
    um_y = um_y + um_y_change

    screen.fill(BLACK)
    #점수 보여주기
    msg = font.render("Score: " + str(score), True, YELLOW)
    screen.blit(msg,[0,0])
    
    rec_umbrella = screen.blit(umbrella, [um_x, um_y])
    
    #우박 그리기
    for i in range(len(stone)-control_num):
        rec_stone = pygame.draw.circle(screen, LIGHTBLUE,stone[i],7)
        if rec_stone.colliderect(rec_umbrella):
            running = False
        else:
            stone[i][1] = stone[i][1] + stone_y_change
            
        #우박이 윈도우 영역을 벗어나면 새로 좌표 지정
        if stone[i][1] > 600:
            stone[i][0] = random.randint(1, 750)   # x 좌표
            stone[i][1] = random.randint(-50,100) # y 좌표
            score += 1
    
    pygame.display.flip()
    
    c_time = time.time()        #현재 시각
    #증가시킬 수 있는 우박이 남아있고 기준시각과 현재 시각의 차이가 3초보다 크다면
    # 우박의 개수와 속도 증가
    if (c_time - st_time) > 3 and control_num > 0:
        control_num = control_num - 1
        fps += 1
        st_time = time.time()    # 기준 시각 변경
    clock.tick(fps)
    
#종료 메시지
endmsg = font.render("Game Over",True, RED)
screen.blit(endmsg,[350,300])
pygame.display.flip()
pygame.time.delay(1500)

pygame.quit()

    
