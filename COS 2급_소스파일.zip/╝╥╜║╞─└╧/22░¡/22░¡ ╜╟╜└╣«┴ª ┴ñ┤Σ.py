a=int(input("가로 길이를 입력하세요 :"))
b=int(input("세로 길이를 입력하세요 :"))
c=int(input("높이를 입력하세요 :"))
print("직육면체의 부피는 %d입니다"%(a*b*c))
