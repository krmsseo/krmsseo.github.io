a=input("좋아하는 수를 입력하세요 :")

print(int(a)+1)
