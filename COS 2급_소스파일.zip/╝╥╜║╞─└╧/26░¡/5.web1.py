import webbrowser

print("안녕하세요~ 저는 여러분의 친구 용이랍니다~")
print("궁금하신 점이 있으시면 언제든 제가 도와드릴게요~")

q1=input("그럼 궁금하신 내용을 적어보세요:  ")

u1="www.google.co.kr/search?q="+q1
webbrowser.open(u1)      
