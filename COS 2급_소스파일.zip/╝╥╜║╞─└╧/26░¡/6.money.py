won=int(input("얼마를 환전하실 건가요?"))
eur=won/1285.68

print("%8.2f 유로 입니다"%eur)
