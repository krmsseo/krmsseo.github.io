a1=int(input("어른 몇 명이신가요?"))
a2=int(input("아이 몇 명이신가요?"))

sum1=a1*1000
sum2=a2*500

print("입장료 발권 내역")
print("어른 %d명  %d원"%(a1,sum1))
print("아이 %d명  %d원" %(a2,sum2))
print("총액: %d원" %(sum1+sum2))




