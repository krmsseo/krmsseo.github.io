test1=int(input("필기점수:"))
test2=int(input("실기점수:"))

sum=test1+test2
avg=sum/2

print("합계는 %d점 이고, 평균은 %5.2f 입니다"%(sum,avg))
