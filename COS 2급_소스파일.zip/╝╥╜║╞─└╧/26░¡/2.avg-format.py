a=5
b=32
c=a+b
print("%d와 %d의 평균은 %4.1f"%(a,b,c))
