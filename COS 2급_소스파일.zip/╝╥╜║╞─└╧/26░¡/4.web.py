import webbrowser

q=input()

#url="www.google.co.kr/search?q="+q
url="https://search.naver.com/search.naver?sm=top_hty&fbm=1&ie=utf8&query="+q
webbrowser.open(url)
