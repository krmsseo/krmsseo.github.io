import turtle as t
t.shape("turtle")
t.forward(100)
