import turtle 
p=turtle.Pen( ) 
p.shape("turtle")
p.circle(30)
