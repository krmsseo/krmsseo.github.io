for x in range(0,5):
    print("안녕")
    
