import turtle as t
t.shape("turtle")
t.forward(100)

t.up()

t.right(90)
t.forward(20)

t.right(90)

t.down()

t.forward(100)

