a=5
b=32
c=(a+b)/2
print(c)
