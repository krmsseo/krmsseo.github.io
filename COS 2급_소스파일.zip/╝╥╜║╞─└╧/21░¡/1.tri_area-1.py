a=5
b=10
c=5*10/2
print(c)
