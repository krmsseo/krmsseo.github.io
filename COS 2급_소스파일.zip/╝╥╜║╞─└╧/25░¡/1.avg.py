a=5
b=32
c=(a+b)/2
print(c)
print(a,"와",b,"의 평균은" ,c)

