a1=int(input("어른 몇 명이신가요?"))
a2=int(input("아이 몇 명이신가요?"))

sum1=a1*1000
sum2=a2*500

print("입장료 발권 내역")
print("어른",a1,"명", sum1,"원")
print("아이",a2,"명", sum2,"원")
print("총액:", sum1+sum2,"원")



