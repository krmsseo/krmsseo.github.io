b=input("넌 몇 살이니?")

print(int(b)+1)

print(b,"살 이구나~ 난",int(b)+1,"살 이야. 너보다 한 살 많네~")

