
import random

while True:
    w=input(">>> ")
    if w=="q":
        break
    
    if w in ['안녕','하이','hi','하이루'] :
        print( random.choice(['안녕하세요','안녕','Hi~']))
    elif w in ['나이','몇 살','년생']:
        print( random.choice(['21세야~','2000년생이야','글쎄 비밀인데~','그게 왜 궁금해?']))
    elif w in ['노래','음악','가수']:
        print("내가 좋아하는 음악은 퀸의 음악이야~ 너는?")
    else:
        print(random.choice(['그렇구나','우아~','무슨 뜻인지 잘 모르겠어']))
    
    
      
