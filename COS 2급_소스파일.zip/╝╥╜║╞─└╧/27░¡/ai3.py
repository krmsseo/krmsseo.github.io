import random

greet = ['안녕','하이','hi','하이루']
age = ['나이','몇 살','년생']
song = ['노래','음악','가수']

while True:
    w = input(">>")

    if w == 'q':
        break
  
    for a in greet + age + song:
        if a in greet and a in w:
            print(random.choice(['안녕하세요','하이룽','Hello']))
            break
        elif a in age and a in w:
            print(random.choice(['21세야~','2000년생이야','글쎄 비밀인데~','그건 왜']))
            break
        elif a in song and a in w:
            print('내가 좋아하는 음악은 퀸의 음악이야~ 너는?')
            break
    #for 문을 break 문에 의해 빠져나온 것이 아니라 모든 범위값동안
    #반복 loop 를 돌았다면 for 문에 대한 else 문장이 실행된다.
    else:
        print(random.choice(['그렇구나','우아~','무슨 뜻인지 모르겠어']))
