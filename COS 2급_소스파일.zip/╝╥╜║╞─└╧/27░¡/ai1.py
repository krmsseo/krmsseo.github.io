import webbrowser

print("안녕하세요~ 고객님")
print("여러분을 도와 드릴 상담봇 궁구미 입니다~")
print("전화번호 안내,교환,환불 등을 안내해 드리겠습니다. ") 
print("감사합니다.\n\n") ;


while True:
    quest=input("궁금하신 내용을 적어주세요 : ")
    if quest=="q":
        break
    
    if "환불" in quest:
        print("고객님~ 환불에 대해 궁금하시군요~")
        print("환불을 원하실 경우 상품 수령 후 7일 이내에 센터에 접수해 주시기 바랍니다")
        print("전화: 111-1111  혹은 이메일: aaa@aa.aa 로 신청 부탁드리겠습니다")
        print("감사합니다.\n\n")

    elif "교환" in quest:
        print(" 고객님 교환을 원하시면, 상품수령 후 7일 이내 반송신청해 주시면 감사하겠습니다")
        print("행복한 하루 되세요~\n\n")
              
    elif "전화" in quest:
        print("고객님~ 전화번호는 111-11111  이며 이메일: aaa@aa.aa로 문의해 주셔도 됩니다.")
        print("감사합니다.")
        print("행복한 하루 되세요~\n\n")
    
    else:
         print("고객님 죄송합니다. 이 질문에는 대답할 수가 없습니다.")
         print("자세한 문의사항은 111-1111로 전화 주시면 감사하겠습니다\n\n")
         webbrowser.open("https://search.naver.com/search.naver?sm=top_hty&fbm=1&ie=utf8&query="+quest)


