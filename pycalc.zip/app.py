# -*- coding: utf-8 -*-
"""
Created on Thu Apr 15 18:07:05 2021

Build the Calculator GUI Application using QtDesigner & Python 
@author: Moonseog
"""



from PyQt5.QtWidgets import QApplication, QWidget
from pycalc_ui import Ui_Form
from functools import partial
import sys

ERROR_MSG = 'ERROR'

class PyCalcUi(QWidget, Ui_Form):
    # Snip
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        
    def setDisplayText(self, text):
        """Set lineEdit's text."""
        self.lineEdit.setText(text)
        self.lineEdit.setFocus()

    def displayText(self):
        """Get lineEdit's text."""
        return self.lineEdit.text()

    def clearDisplay(self):
        """Clear the lineEdit."""
        self.setDisplayText('')        


class PyCalcCtrl:
    """PyCalc Controller class."""
    def __init__(self, model, view):
        """Controller initializer."""
        self._evaluate = model
        self._view = view
        # Connect signals and slots
        self._connectSignals()
        
    def _calculateResult(self):
        """Evaluate expressions."""
        result = self._evaluate(expression=self._view.displayText())
        self._view.setDisplayText(result)
        
    def _buildExpression(self, sub_exp):
        """Build expression."""
        expression = self._view.displayText() + sub_exp
        self._view.setDisplayText(expression)

    def _connectSignals(self):
        """Connect signals and slots.""" 
        self._view.pushButton_1.clicked.connect(partial(self._buildExpression,'1'))
        self._view.pushButton_2.clicked.connect(partial(self._buildExpression,'2'))
        self._view.pushButton_3.clicked.connect(partial(self._buildExpression,'3'))
        self._view.pushButton_4.clicked.connect(partial(self._buildExpression,'4'))
        self._view.pushButton_5.clicked.connect(partial(self._buildExpression,'5'))
        self._view.pushButton_6.clicked.connect(partial(self._buildExpression,'6'))
        self._view.pushButton_7.clicked.connect(partial(self._buildExpression,'7'))
        self._view.pushButton_8.clicked.connect(partial(self._buildExpression,'8'))
        self._view.pushButton_9.clicked.connect(partial(self._buildExpression,'9'))
        self._view.pushButton_open.clicked.connect(partial(self._buildExpression,'('))
        self._view.pushButton_close.clicked.connect(partial(self._buildExpression,')'))
        self._view.pushButton_0.clicked.connect(partial(self._buildExpression,'0'))
        self._view.pushButton_00.clicked.connect(partial(self._buildExpression,'00'))
        self._view.pushButton_plus.clicked.connect(partial(self._buildExpression,'+'))
        self._view.pushButton_minus.clicked.connect(partial(self._buildExpression,'-'))
        self._view.pushButton_mul.clicked.connect(partial(self._buildExpression,'*'))
        self._view.pushButton_divide.clicked.connect(partial(self._buildExpression,'/'))
        self._view.pushButton_dot.clicked.connect(partial(self._buildExpression,'.'))
               
        self._view.pushButton_equal.clicked.connect(self._calculateResult)
        self._view.lineEdit.returnPressed.connect(self._calculateResult)
        self._view.pushButton_C.clicked.connect(self._view.clearDisplay)

def evaluateExpression(expression):
    """Evaluate an expression."""
    try:
        result = str(eval(expression, {}, {}))
    except Exception:
        result = ERROR_MSG

    return result        

def main():
    """Main function."""
    # Create an instance of QApplication
    pycalc = QApplication(sys.argv)
    # Show the calculator's GUI
    view = PyCalcUi()
    view.show()
    # Create instances of the model and the controller
    model = evaluateExpression
    PyCalcCtrl(model=model, view=view)
    # Execute calculator's main loop
    sys.exit(pycalc.exec_())
    
if __name__ == '__main__':
    main()